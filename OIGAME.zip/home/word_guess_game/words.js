// words for guessing and hints
let words = [
    {
        word: "JavaScript",
        hint: "A Programming language that embedded into HTML"
    },
    {
        word: "chunithm",
        hint: "An arcade music game that needs to keep waving hands"
    },
    {
        word: "python",
        hint: "A programming language that the logo got 2 snakes."
    },
    {
        word: "coffee",
        hint: "A type of drinks that made from bean."
    },
    {
        word: "loong",
        hint: "The chinese kind of dragons."
    },
    {
        word: "pokemon",
        hint: "Gotta catch'em all."
    },
    {
        word: "cow",
        hint: "moo."
    },
    {
        word: "sushi",
        hint: "A type of food from Japan."
    },
    {
        word: "photoshop",
        hint: "A photo editing software."
    },
    {
        word: "pixel",
        hint: "The component of raster image."
    },
    {
        word: "vector",
        hint: "A type of image that remains clear after zooming in."
    },
]